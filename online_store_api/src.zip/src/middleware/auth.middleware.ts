import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const SECRET = process.env.JWT_SECRET || 'dev_secret';

export function authMiddleware(req: Request, res: Response, next: NextFunction): any {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    const token = authHeader.split(' ')[1];
    try {
        const payload = jwt.verify(token, SECRET) as { userId: string };
        (req as any).user = { id: payload.userId };
        next();
    } catch (err) {
        return res.status(401).json({ error: 'Invalid token' });
    }
}
